﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestAutomation
{
    public class CartPage
    {
        private IWebDriver driver;
        List<int> dataProductIds = new List<int>();

        public CartPage(IWebDriver driver)
        {
            this.driver = driver;
        }

        public int GetCartItemCount()
        {
            Thread.Sleep(10000);
            var cartItems = driver.FindElements(By.CssSelector(".cart_item"));
            return Convert.ToInt32(cartItems.Count);
        }

        public void WhenIAddFourRandomItemsToMyCart(int count)
        {
            var getProductsDriver = driver.FindElements(By.CssSelector(".product")).ToList();

            for (int i = 0; i <= count; i++)
            {
                Random rnd = new Random();
                int randomCart = rnd.Next(1, getProductsDriver.Count);
                var currItem = getProductsDriver[randomCart - 1];

                try
                {
                    var addToCard = currItem.FindElement(By.CssSelector(".ajax_add_to_cart"));
                }
                 catch(Exception)
                {
                    i--;
                }
                getProductsDriver.RemoveAt(randomCart - 1);
            }
        }

        public void AddToCard(IWebElement webElement)
        {
            webElement.Click();
        }
       
        public void WhenIViewMyCart()
        {
            driver.FindElement(By.XPath("//a[contains(text(),'Cart']")).Click();

        }

        public void WhenISearchForTheLowestPriceItem()
        {
            var cartItems = driver.FindElements(By.CssSelector(".cart_item"));
            var web = cartItems.First();
            var lowestDriver = web.FindElement(By.CssSelector(".woocommerce-Price-amount"));
            var lowestPrice = Convert.ToDecimal(lowestDriver.Text.TrimStart('$')); ;

            foreach (var item in cartItems)
            {
                var cartIs = item.FindElement(By.CssSelector(".woocommerce-Price-amount"));
                if (lowestPrice > Convert.ToDecimal(cartIs.Text.TrimStart('$')))
                {
                    lowestPrice = Convert.ToDecimal(cartIs.Text.TrimStart('$'));
                }
            }

        }


        public void WhenIAmAbleToRemoveTheLowestPriceItemFromMyCart()
        {
            var cartItems = driver.FindElements(By.CssSelector(".cart_item"));
            var web = cartItems.First();
            var lowestDriver = web.FindElement(By.CssSelector(".woocommerce-Price-amount"));
            var lowestPrice = Convert.ToDecimal(lowestDriver.Text.TrimStart('$'));

            foreach (var item in cartItems)
            {
                var cartIs = driver.FindElement(By.CssSelector(".woocommerce-Price-amount"));
                if (lowestPrice > Convert.ToDecimal(cartIs.Text.TrimStart('$')))
                {
                    lowestPrice = Convert.ToDecimal(cartIs.Text.TrimStart('$'));
                    web = item;
                }
            }

            web.FindElement(By.CssSelector(".remove")).Click();
            }
    }
}
