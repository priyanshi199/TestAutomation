﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;
using NUnit.Framework;

namespace TestAutomation.StepDefinitions
{

    [Binding]
    public sealed class FeatureStepDefinitions
    {
        private IWebDriver driver;
        private CartPage cartPage;


        [Given(@"I am on the dummy website")]
        public void GivenIAmOnTheDummyWebsite()
        {
            driver = new ChromeDriver();
            driver.Manage().Window.Maximize();
            driver.Navigate().GoToUrl("https://cms.demo.katalon.com/");
            cartPage = new CartPage(driver);
        }

        [When(@"I add four random items on my cart")]
        public void WhenIAddFourRandomItemsOnMyCart()
        {
            cartPage.WhenIAddFourRandomItemsToMyCart(4);
        }

        [When(@"I view my cart")]
        public void WhenIViewMyCart()
        {
            cartPage.WhenIViewMyCart();
        }

        [Then(@"I find total four items listed in my cart")]
        public void ThenIFindTotalFourItemsListedInMyCart()
        {
            Assert.AreEqual(4,cartPage.GetCartItemCount());
        }

        [When(@"I search for the lowest price item")]
        public void WhenISearchForTheLowestPriceItem()
        {
            cartPage.WhenISearchForTheLowestPriceItem();
        }

        [When(@"I am able to remove the lowest price item from my cart")]
        public void WhenIAmAbleToRemoveTheLowestPriceItemFromMyCart()
        {
            cartPage.WhenIAmAbleToRemoveTheLowestPriceItemFromMyCart();
        }

        [Then(@"I am able to verify three items in my cart")]
        public void ThenIAmAbleToVerifyThreeItemsInMyCart()
        {
            Assert.AreEqual(3, cartPage.GetCartItemCount());
        }

        [AfterScenario]
        public void TearDown()
        {
            driver.Quit();
        }
    }
}
